from preorder_app.app import create_app
from flask import render_template

app = create_app()

@app.route("/")
def home():
    try:
        return render_template("index.html")
    except Exception:
        return "Preorder App is Live", 200
