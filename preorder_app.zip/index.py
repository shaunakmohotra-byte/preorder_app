from preorder_app.app import create_app

app = create_app()
