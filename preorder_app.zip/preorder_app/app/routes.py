from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from .store import load_json, save_json, ITEMS_FILE, CARTS_FILE, ORDERS_FILE, USERS_FILE
import datetime, uuid
import os
import json

bp = Blueprint('main', __name__, template_folder='../templates')


# -----------------------
# Helper Functions
# -----------------------

def current_user():
    uid = session.get('user_id')
    if not uid:
        return None
    
    users = load_json(USERS_FILE, [])
    return next((u for u in users if u['id'] == uid), None)


def load_orders():
    try:
        data = load_json(ORDERS_FILE, [])
        if isinstance(data, list):
            return data
        else:
            return []     # safety reset
    except:
        return []

def save_orders(data):
    save_json(ORDERS_FILE, data)



def save_orders(data):
    return save_json(ORDERS_FILE, data)


from utils.repair import repair_json

def load_json(path, default):
    # Repair automatically and return repaired content
    repaired = repair_json(path, type(default))
    return repaired


# -----------------------
# Main Routes
# -----------------------

@bp.route('/')
def index():
    return redirect(url_for('main.menu'))


@bp.route('/menu')
def menu():
    items = load_json(ITEMS_FILE, [])
    return render_template('menu.html', items=items, user=current_user())


@bp.route('/add_to_cart', methods=['POST'])
def add_to_cart():
    user = current_user()
    if not user:
        flash('Please login to add to cart')
        return redirect(url_for('auth.login'))

    item_id = request.form['item_id']
    qty = int(request.form.get('qty', 1))

    carts = load_json(CARTS_FILE, {})
    user_cart = carts.get(user['id'], [])

    existing = next((c for c in user_cart if c['item_id'] == item_id), None)
    if existing:
        existing['qty'] += qty
    else:
        user_cart.append({'item_id': item_id, 'qty': qty})

    carts[user['id']] = user_cart
    save_json(CARTS_FILE, carts)

    flash('Added to cart')
    return redirect(url_for('main.menu'))


@bp.route('/cart')
def view_cart():
    user = current_user()
    if not user:
        flash('Login to view cart')
        return redirect(url_for('auth.login'))

    carts = load_json(CARTS_FILE, {})
    items = {i['id']: i for i in load_json(ITEMS_FILE, [])}
    user_cart = carts.get(user['id'], [])

    cart_details = []
    total = 0

    for c in user_cart:
        it = items.get(c['item_id'])
        if not it:
            continue
        subtotal = it['price'] * c['qty']
        total += subtotal
        cart_details.append({
            'item': it,
            'qty': c['qty'],
            'subtotal': subtotal
        })

    return render_template('cart.html', cart_details=cart_details, total=total, user=user)


@bp.route('/remove_from_cart', methods=['POST'])
def remove_from_cart():
    user = current_user()
    if not user:
        return redirect(url_for('auth.login'))

    item_id = request.form['item_id']

    carts = load_json(CARTS_FILE, {})
    user_cart = carts.get(user['id'], [])

    user_cart = [c for c in user_cart if c['item_id'] != item_id]
    carts[user['id']] = user_cart
    save_json(CARTS_FILE, carts)

    flash('Removed')
    return redirect(url_for('main.view_cart'))

@bp.route('/cart/increase', methods=['POST'])
def cart_increase():
    user = current_user()
    if not user:
        return redirect(url_for('auth.login'))

    item_id = request.form['item_id']

    carts = load_json(CARTS_FILE, {})
    user_cart = carts.get(user['id'], [])

    for c in user_cart:
        if c['item_id'] == item_id:
            c['qty'] += 1
            break

    carts[user['id']] = user_cart
    save_json(CARTS_FILE, carts)

    return redirect(url_for('main.view_cart'))


@bp.route('/cart/decrease', methods=['POST'])
def cart_decrease():
    user = current_user()
    if not user:
        return redirect(url_for('auth.login'))

    item_id = request.form['item_id']

    carts = load_json(CARTS_FILE, {})
    user_cart = carts.get(user['id'], [])

    for c in user_cart:
        if c['item_id'] == item_id:
            if c['qty'] > 1:
                c['qty'] -= 1
            else:
                # If quantity becomes 0, remove it
                user_cart = [x for x in user_cart if x['item_id'] != item_id]
            break

    carts[user['id']] = user_cart
    save_json(CARTS_FILE, carts)

    return redirect(url_for('main.view_cart'))


@bp.route('/checkout', methods=['POST'])
def checkout():
    user = current_user()
    if not user:
        flash('Login to checkout')
        return redirect(url_for('auth.login'))

    carts = load_json(CARTS_FILE, {})
    user_cart = carts.get(user['id'], [])

    if not user_cart:
        flash('Cart empty')
        return redirect(url_for('main.view_cart'))

    items = {i['id']: i for i in load_json(ITEMS_FILE, [])}

    order_items = []
    total = 0

    for c in user_cart:
        it = items.get(c['item_id'])
        if not it:
            continue

        order_items.append({
            'item_id': it['id'],
            'name': it['name'],
            'price': it['price'],
            'qty': c['qty']
        })
        total += it['price'] * c['qty']

    order = {
        'id': str(uuid.uuid4()),
        'user_id': user['id'],
        'user_name': user['name'],
        'items': order_items,
        'total': total,
        'status': 'placed',
        'created_at': datetime.datetime.utcnow().isoformat()
    }

    orders = load_orders()
    orders.append(order)
    save_orders(orders)

    carts[user['id']] = []
    save_json(CARTS_FILE, carts)

    flash('Order placed')
    return redirect(url_for('main.menu'))



@bp.route('/cafeteria')
def cafeteria():
    orders = load_orders()

    # HARD SAFETY CHECK
    if not isinstance(orders, list):
        orders = []

    return render_template("cafeteria.html", orders=orders)




# -----------------------
# Staff Routes
# -----------------------

@bp.route('/staff/orders')
def staff_orders():
    if session.get("role") != "staff":
        return redirect(url_for('auth.login'))

    orders = load_orders()
    return render_template("staff_orders.html", orders=orders)


@bp.route('/staff/update_status/<order_id>', methods=['POST'])
def update_status(order_id):
    if session.get("role") != "staff":
        return redirect(url_for('auth.login'))

    new_status = request.form['status']
    orders = load_orders()

    for o in orders:
        if o["id"] == order_id:
            o["status"] = new_status

    save_orders(orders)
    flash("Status updated")

    return redirect(url_for('main.staff_orders'))
